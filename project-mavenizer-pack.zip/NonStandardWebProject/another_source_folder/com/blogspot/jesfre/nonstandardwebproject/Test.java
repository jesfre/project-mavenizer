/**
 * 
 */
package com.blogspot.jesfre.nonstandardwebproject;

/**
 * @author jesfre
 *
 */
public class Test {

}
